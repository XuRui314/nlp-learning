CURRENT_DIR=`pwd`
CUDA_EXPERIMENT
export BERT_BASE_DIR=bert-base-chinese
export DATA_DIR=/home/wangrui/2022材料/simpler/dataset
export OUTPUR_DIR=$CURRENT_DIR/outputs
TASK_NAME="bdci"
#
python run_ner_crf_s.py \
  --model_type=bert \
  --model_name_or_path=$BERT_BASE_DIR \
  --task_name=$TASK_NAME \
  --do_train \
  --do_eval \
  --do_lower_case \
  --data_dir=$DATA_DIR/${TASK_NAME}/ \
  --train_max_seq_length=128 \
  --eval_max_seq_length=512 \
  --per_gpu_train_batch_size=24 \
  --per_gpu_eval_batch_size=24 \
  --learning_rate=3e-5 \
  --crf_learning_rate=1e-3 \
  --num_train_epochs=4.0 \
  --logging_steps=50 \
  --save_steps=50 \
  --output_dir=$OUTPUR_DIR/ \
  --overwrite_output_dir \
  --seed=42
